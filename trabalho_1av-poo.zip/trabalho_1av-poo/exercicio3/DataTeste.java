package exercicio3;

public class DataTeste {
    public static void main(String[] args) {
        Data.Fatura fatura = new Data().new Fatura(9, 28, 2024);
        fatura.displayData();
    }
}
