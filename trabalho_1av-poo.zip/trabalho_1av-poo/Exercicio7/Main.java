package Exercicio7;

public class Main {
    public static void main(String[] args) {
        Cachorro c1 = new Cachorro();
        c1.emitirSom();
        Gato g1 = new Gato();
        g1.emitirSom();
    }
}
