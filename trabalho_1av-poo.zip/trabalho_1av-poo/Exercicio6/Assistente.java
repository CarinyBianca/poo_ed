package Exercicio6;

public class Assistente extends Funcionario {

}
